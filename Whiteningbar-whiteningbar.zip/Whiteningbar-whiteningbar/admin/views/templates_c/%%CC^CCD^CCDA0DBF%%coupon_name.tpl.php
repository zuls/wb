<?php /* Smarty version 2.6.26, created on 2017-04-17 11:13:20
         compiled from reserve/coupon_name.tpl */ ?>
<div id=coupon_name><?php echo $this->_tpl_vars['coupon_name']; ?>
</div>
