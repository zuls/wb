<?php /* Smarty version 2.6.26, created on 2017-03-09 00:37:32
         compiled from calendar_footer.tpl */ ?>
		<footer class="clear clearfix" id="footer">
		<p class="clear tc txt-sm">Copyright (C) 2014 WhiteningBAR. All Rights Reserved.</p>
	</footer>