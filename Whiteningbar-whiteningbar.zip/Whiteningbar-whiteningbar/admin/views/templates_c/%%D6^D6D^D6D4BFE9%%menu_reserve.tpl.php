<?php /* Smarty version 2.6.26, created on 2017-04-19 18:03:16
         compiled from reserve/menu_reserve.tpl */ ?>
<ul class="tab clearfix mt20">
	<li><a class='<?php if($_SESSION['tab']=='reserve')echo"active" ?>' href="/reserve/list/">予約一覧</a></li>
</ul>
<div class="clear"> </div>