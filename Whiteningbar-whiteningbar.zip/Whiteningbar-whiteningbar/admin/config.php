<?php
// サイトタイトル
define("STR_SITE_TITLE", "WhiteningBAR: 管理画面");
define("FOOTER_COPYRIGHT", "Copyright &copy; 2014 WhiteningBar All Rights Reserved.");

// サイトのルートディレクトリパス
define("ROOT_PATH", realpath(dirname(__FILE__) . "/."));

// Log4PHPの設定ファイル
define("LOG4PHP_CONFIGURATION", "/var/workspace/Whitening/whitening/admin/log4php.properties");


?>