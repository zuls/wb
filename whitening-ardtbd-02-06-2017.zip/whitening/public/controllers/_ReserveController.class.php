<?php
class ReserveController extends AppRootController {


	/**
	 * コンストラクタ
	 */
	public function __construct() {
		parent::__construct();

		require_once sprintf("%s/dao/Category1Dao.class.php", MODEL_PATH);

	}

	/**
	 * 予約画面の表示
	 */
	public function displayAction() {


		$commonDao = new CommonDao();

		$login_member=$this->getMemberSession();


		//店舗
		$tmp=$commonDao->get_data_tbl("shop","","","shop_no");
		$shopArr=makePulldownTableList($tmp, "shop_no", "name",1);

		//初回用メニュー
		$menuArr=$commonDao->get_data_tbl("mst_menu","kind_flg","0","menu_no");



		$this->view->assign("shopArr", $shopArr);
		$this->view->assign("menuArr", $menuArr);


		// HTTPレスポンスヘッダ情報出力
		$this->outHttpResponseHeader();


		$this->setTemplatePath("reserve/index.tpl");

		return;

	}

	/**
	 * 予約画面の表示
	 */
	public function listAction() {


		$commonDao = new CommonDao();
		$memberDao = new MemberDAO();

		$login_member=$this->getMemberSession();

		//マイページの予約から予約画面に入った時に、ログインが切れていたら、ログインのし直し
		if($_POST[reserve] && !$login_member){
			header("location:/");
			exit;

		}


		if($_POST[submit] || isset($_GET[back])){


			if($_POST){
				$_SESSION["reserve_input_data"]=$_POST;
			}
			$search=$_SESSION["reserve_input_data"];

			//---------------- 入力チェック ---------------------------
			$baseData=CommonChkArray::$reserveCheckData;
			$this->check($search,$baseData);

			//予約の日付のチェック
			//予約の日付、時間が過去であればエラー
			if($search[reserve_date] && $search[reserve_time]){
				$tdy=date("Y/m/d H:i");
				$r_date=$search[reserve_date]." ".$search[reserve_time];
				if($tdy>=$r_date){
					$this->addMessage("reserve_date", "ご予約希望の日時をご確認ください。過去の日時になっています");
				}

				//----------- 予約日付の曜日が店舗の休日であればエラー-----------------------
				$chkArr[dtTmp]=explode("/",$search[reserve_date]);//予約日をばらす
				$chkArr[timeTmp]=explode(":",$search[reserve_time]);//予約時間をばらす

				$youbi=date(N,mktime($chkArr[timeTmp][0],$chkArr[timeTmp][1],0,$chkArr[dtTmp][1],$chkArr[dtTmp][2],$chkArr[dtTmp][0]));
				$tmp=$commonDao->get_data_tbl("shop_attr",array("shop_no","attr_key"),array($search[shop_no],"days"));

				$list = array();
				if($tmp){
					foreach ($tmp as $a) {
					    $list[] = $a['attr_value'];
					}
				}
				if($list){
					if(!in_array($youbi, $list)){
						$this->addMessage("reserve_date", "ご予約希望日は店舗の休日となっております。<br />申し訳ございませんが、他の日をご指定ください");

					}
				}
			}


			//-------------- ここまで -----------------------------------
			if (count($this->getMessages()) >0) {

				foreach($this->getMessages() as $err_msg){
					$result_messages[$err_msg->getMessageLevel()]=$err_msg->getMessageBody();
				}

				$this->view->assign("result_messages", $result_messages);
			}
			else {

				//ご希望コースの所要時間
				$tmp=$commonDao->get_data_tbl("mst_menu","menu_no",$search[menu_no]);
				$chkArr[rtimes]=$tmp[0][times];//所要時間

				//店舗のブース数
				$tmp=$commonDao->get_data_tbl("shop_attr",array("shop_no","attr_key"),array($search[shop_no],"booth"));
				$chkArr[shop_booth_cnt]=$tmp[0][attr_value];


				//------------ 店舗の営業終了時間からメニューの所要時間を引く。その時間を超える予約時間は表示させない。--------------
				//そして、営業開始時間前の時間は表示させない。
				$youbi=date(N);//月曜を1とする日付数値
				$tmpH=$commonDao->get_data_tbl("shop_attr",array("shop_no","attr_key"),array($search[shop_no],"to_$youbi_h"));
				if($tmpH){//曜日の営業時間設定がある場合
					$tmpM=$commonDao->get_data_tbl("shop_attr",array("shop_no","attr_key"),array($search[shop_no],"to_$youbi_m".$youbi));

				}
				else{
					$tmpH=$commonDao->get_data_tbl("shop_attr",array("shop_no","attr_key"),array($search[shop_no],"to_def_h"));
					$tmpM=$commonDao->get_data_tbl("shop_attr",array("shop_no","attr_key"),array($search[shop_no],"to_def_m"));
				}
				//営業終了時間から、選択したメニューの所要時間を引いた時間
				$shopEndTime=mktime($tmpH[0][attr_value], $tmpM[0][attr_value]-$chkArr[rtimes],0,$chkArr[dtTmp][1],$chkArr[dtTmp][2],$chkArr[dtTmp][0]);

				$tmpH=$commonDao->get_data_tbl("shop_attr",array("shop_no","attr_key"),array($search[shop_no],"fromo_$youbi_h"));
				if($tmpH){//曜日の営業時間設定がある場合
					$tmpM=$commonDao->get_data_tbl("shop_attr",array("shop_no","attr_key"),array($search[shop_no],"from_$youbi_m".$youbi));

				}
				else{
					$tmpH=$commonDao->get_data_tbl("shop_attr",array("shop_no","attr_key"),array($search[shop_no],"from_def_h"));
					$tmpM=$commonDao->get_data_tbl("shop_attr",array("shop_no","attr_key"),array($search[shop_no],"from_def_m"));
				}
				$shopStartTime=mktime($tmpH[0][attr_value], $tmpM[0][attr_value],0,$chkArr[dtTmp][1],$chkArr[dtTmp][2],$chkArr[dtTmp][0]);




				//------------ 予約スケジュールチェック 予約日時の前後2時間の予約状況を表示 ---------------------------

				//過去２時間
				for($i=8;$i>=1;$i--){
					$plus=15*$i;
					$chkArr[start_time]=date("H:i",mktime($chkArr[timeTmp][0],$chkArr[timeTmp][1]-$plus,0,$chkArr[dtTmp][1],$chkArr[dtTmp][2],$chkArr[dtTmp][0]));

					$chkSstart_time=mktime($chkArr[timeTmp][0],$chkArr[timeTmp][1]-$plus,0,$chkArr[dtTmp][1],$chkArr[dtTmp][2],$chkArr[dtTmp][0]);

					//営業開始時間前はチェックしない
					if($chkSstart_time>=$shopStartTime){
						$this->checkReserve($chkArr, $search);
					}
				}
				//予約時間＋未来２時間
				for($i=0;$i<=8;$i++){
					$plus=15*$i;
					$chkArr[start_time]=date("H:i",mktime($chkArr[timeTmp][0],$chkArr[timeTmp][1]+$plus,0,$chkArr[dtTmp][1],$chkArr[dtTmp][2],$chkArr[dtTmp][0]));

					//店舗営業時間-メニュー所要時間とのチェック用
					$chkSstart_time=mktime($chkArr[timeTmp][0],$chkArr[timeTmp][1]+$plus,0,$chkArr[dtTmp][1],$chkArr[dtTmp][2],$chkArr[dtTmp][0]);

					if($shopEndTime>=$chkSstart_time){
						$this->checkReserve($chkArr, $search);
					}
					else{
						break;
					}
				}

				$zanArr=$this->getArr();

				//選択日時の曜日取得
				$weekjp_array = array('日', '月', '火', '水', '木', '金', '土');
				//タイムスタンプを取得
				$ptimestamp = mktime(0, 0, 0, $chkArr[dtTmp][1],$chkArr[dtTmp][2],$chkArr[dtTmp][0]);
				//曜日番号を取得
				$weekno = date('w', $ptimestamp);
				//日本語の曜日を出力
				$weekjp = $weekjp_array[$weekno];


			}

		}



		//店舗プルダウン
		$tmp=$commonDao->get_data_tbl("shop","","","shop_no");
		$shopArr=makePulldownTableList($tmp, "shop_no", "name",1);


		//ログイン後のマイページからの予約の場合は、コースに紐づいているメニューを表示
		if($login_member){
			if($_POST[reserve]){
				$buy_no=key($_POST[reserve]);
			}else if($_POST){
				$buy_no=$_POST[buy_no];
			}
			else{
				$buy_no=$_GET[back];
			}

			$sql="select * from mst_menu as m,member_buy as b where m.course_no=b.course_no and b.buy_no=".$buy_no;

			$menutmp=$commonDao->get_sql($sql);



//		$menutmp=$commonDao->get_data_tbl("mst_menu","course_no",$db_courseArr[course_no]);

		//使用するコースの残チケットにより、選べるメニューを変える
		$tmp=$memberDao->getCourseCntInfo($buy_no);
		$cnt=count($tmp);

		if(!$tmp){
				$sql="select c.number from member_buy as b, mst_course as c where b.course_no=c.course_no and b.buy_no=".$buy_no;
				$tmp=$commonDao->get_sql($sql);
		}


		$zan=$tmp[0][number]-$cnt;
		for($i=0;$i<count($menutmp);$i++){
			if($menutmp[$i][use_count]<=$zan){
				$menuArr[]=$menutmp[$i];
			}
		}


//		$menuArr=makePulldownTableList($tmp, "menu_no", "name");
//		$this->view->assign("menuArr", $menuArr);

			$this->view->assign("buy_no", $buy_no);

		}
		else{
			//初回用メニュー取得
			$menuArr=$commonDao->get_data_tbl("mst_menu","kind_flg","0","menu_no");

		}


		$this->view->assign("shopArr", $shopArr);
		$this->view->assign("menuArr", $menuArr);
		$this->view->assign("search", $search);
		$this->view->assign("zanArr", $zanArr);
		$this->view->assign("weekjp", $weekjp);


		// HTTPレスポンスヘッダ情報出力
		$this->outHttpResponseHeader();


		$this->setTemplatePath("reserve/index.tpl");

		return;

	}

	/*  予約日時の予約チェック */
	function checkReserve($chkArr, $search){

		$dao=new ReserveDAO();
		$zanArr=$this->getArr();

		$zanCnt=count($zanArr);

			//終了時間
			$endTmp=explode(":", $chkArr[start_time]);
			$ins[end_time]=date("H:i",mktime($endTmp[0],$endTmp[1]+$chkArr[rtimes],0,$chkArr[dtTmp][1],$chkArr[dtTmp][2],$chkArr[dtTmp][0]));

			$ins[shop_no]=$search[shop_no];
			$ins[reserve_date]=$search[reserve_date];
			$ins[start_time]=$chkArr[start_time];

			//予約希望時間帯現在の予約数(開始時間で見る）
			//$reserve_count=$dao->getReserveCount($ins,"start");
			$reserve_count=$dao->getReserveCount3($ins);

			$zan=$chkArr[shop_booth_cnt]-($search[number]+$reserve_count);
			if($zan<0){//予約不可
				$zanArr[$zanCnt][str]="0";
				$zanArr[$zanCnt][start_time]=$chkArr[start_time];
				$zanArr[$zanCnt][detail]="";
			}
			else if($zan==0){//今回の予約確定により、残りがなくなる場合は残りわずか
				$zanArr[$zanCnt][str]="1";
				$zanArr[$zanCnt][start_time]=$chkArr[start_time];
				$zanArr[$zanCnt][detail]=$ins[reserve_date]."_".$chkArr[start_time]."_".$ins[end_time]."_".$ins[shop_no]."_".$search[menu_no]."_".$search[number];
			}
			else{//他は予約OK
				$zanArr[$zanCnt][str]="2";
				$zanArr[$zanCnt][start_time]=$chkArr[start_time];
				$zanArr[$zanCnt][detail]=$ins[reserve_date]."_".$chkArr[start_time]."_".$ins[end_time]."_".$ins[shop_no]."_".$search[menu_no]."_".$search[number];
			}

			$this->setArr($zanArr);

			return true;
	}

	function setArr($arr){
		$this->arr=$arr;
	}
	function getArr(){
		return $this->arr;
	}



	/**
	 * 予約アンケートのフォーム表示と入力チェック等
	 */
	public function surveyAction() {


		$commonDao = new CommonDao();

		$login_member=$this->getMemberSession();

		//ログイン中の場合、登録は終わっているので、確認画面へ
		if($login_member){

			//予約内容のセッション
			$_SESSION[reserve_detail]=$_POST[reserve_detail];

			$reserve_detail=$this->setReserveDetail();

			$this->view->assign("buy_no", $_POST[buy_no]);
			$this->view->assign("reserve_datail", $reserve_detail);



			// HTTPレスポンスヘッダ情報出力
				$this->outHttpResponseHeader();
				$this->setTemplatePath("reserve/reserve_confirm.tpl");
				return;

		}



		//予約アンケートの取得
		$setArr=$commonDao->get_data_tbl("mst_form_set","","","v_order ");

		if($_POST[submit]){

			//------ 入力チェック ------------
			$input_data=$_POST;
			$_SESSION["survey_input_data"]=$_POST;

			for($i=0;$i<count($setArr);$i++){
				$komoku_no=$setArr[$i][komoku_no];

				//必須チェック
				if($setArr[$i][status]==1){//必須
					if($setArr[$i][form_type]==5){
						if(count($input_data[no][$komoku_no])==0) $this->addMessage("err", $setArr[$i][name]."を選択してください。");
					}
					else{
						if($input_data[no][$komoku_no]==""){
							if($setArr[$i][form_type]<=2){
								$this->addMessage("err".$komoku_no, $setArr[$i][name]."を入力してください。");
							}
							else{
								 $this->addMessage("err".$komoku_no, $setArr[$i][name]."を選択してください。");
							}
						}
					}
				}

				//入力チェック
/*
			"0" => "入力制限無し",
			"1" => "半角英数字のみ",
			"2" => "数字のみ",
			"5" => "数字と「-」",
			"12" => "数字と小数点",
			"7" => "全角ひらがなのみ",
			"6" => "全角カタカナのみ",
			"3" => "メールアドレス",
*/
				if($setArr[$i][form_type]<=2 && $input_data[no][$komoku_no]!=""){
					$chkNo=$setArr[$i][in_chk];
					$ret=chkString($input_data[no][$komoku_no],$chkNo,$setArr[$i][in_max],$setArr[$i][in_min]);

					if($ret != 0){
						if($ret == 1){
							$this->addMessage("err".$komoku_no, $setArr[$i][name]."に入力された文字数が長すぎます。".$setArr[$i][in_max]."文字以下で入力してください。");
						}elseif($ret == 5){
							$this->addMessage("err".$komoku_no, $setArr[$i][name]."に入力された文字数が短すぎます。".$setArr[$i][in_min]."文字以上で入力してください。");
						}else{
							if($inputChk == 1){
								$this->addMessage("err".$komoku_no, $setArr[$i][name]."は半角英数で入力してください");
							}elseif($inputChk == 3){
								$this->addMessage("err".$komoku_no, $setArr[$i][name]."を正しく入力してください");
							}elseif($inputChk == 6){
								$this->addMessage("err".$komoku_no, $setArr[$i][name]."は全角カタカナで入力してください");
							}elseif($inputChk == 7){
								$this->addMessage("err".$komoku_no, $setArr[$i][name]."は全角かなで入力してください");
							}elseif($inputChk == 12){
								$this->addMessage("err".$komoku_no, $setArr[$i][name]."は半角数字と｢.｣で入力してください");
							}elseif($inputChk == 5){
								$this->addMessage("err".$komoku_no, $setArr[$i][name]."は半角数字と｢-｣で入力してください");
							}else{
								$this->addMessage("err".$komoku_no, $setArr[$i][name]."は半角数字で入力してください");
							}
						}
					}
				}
			}

			if (count($this->getMessages()) >0) {
				foreach($this->getMessages() as $err_msg){
					$result_messages[$err_msg->getMessageLevel()]=$err_msg->getMessageBody();
				}
				$this->view->assign("result_messages", $result_messages);
			}
			else{
				//エラーが無ければ、登録フォームを出す

				header("location:/reserve/regist/");
				return;

			}

		}
		else{

			//会員登録確認画面から、予約画面に戻って、再度予約登録処理をした場合には、セッションが残っている。
			if($_SESSION["survey_input_data"]){
				$input_data=$_SESSION["survey_input_data"];
			}

			//予約内容のセッション
			$_SESSION[reserve_detail]=$_POST[reserve_detail];
		}


		//選択肢の項目を取得する（プルダウン,radio,checkboxの場合に使用）
		for($i=0;$i<count($setArr);$i++){
			if($setArr[$i][form_type]==3 || $setArr[$i][form_type]==4 || $setArr[$i][form_type]==5){
				$tmp=$commonDao->get_data_tbl("form_set_value","komoku_no",$setArr[$i][komoku_no]);
				$setArr[$i][opt]=makePulldownTableList($tmp, "name", "name");;
			}
		}

		$this->view->assign("setArr", $setArr);
		$this->view->assign("input_data", $input_data);

		// HTTPレスポンスヘッダ情報出力
		$this->outHttpResponseHeader();

		$this->setTemplatePath("reserve/survey.tpl");

		return;


	}

	/**
	 * 会員登録処理
	 */
	public function registAction() {


		$commonDao = new CommonDao();
		$shopDao=new ShopDao();
		$memberDao=new MemberDao();

		//予約詳細データ
		if(!$_SESSION[reserve_detail]){

			//時間切れエラー/不正エラー

				$this->addMessage("error","タイムアウトエラーです。予約画面から始めてください");


				// HTTPレスポンスヘッダ情報出力
				$this->outHttpResponseHeader();

				$this->setTemplatePath("error.tpl");
				return;

		}
		else{

			//$ins[reserve_date]."_".$chkArr[start_time]."_".$ins[end_time]."_".$ins[shop_no]."_".$search[menu_no]."_".$search[number
			//予約日(yyyy/mm/dd)."_".予約開始時間(hh:ii)."_".予約終了時間(hh:ii)."_".店舗番号."_".メニュー番号."_".人数

			$reserve_datail=$this->setReserveDetail();
			$this->view->assign("reserve_datail", $reserve_datail);

		}

		//config
		$prefArr=CommonArray::$pref_text_array;

		//基本事項
		$baseData=CommonChkArray::$memberRegistCheckData;

		if($_POST[confirm]){
			$_SESSION["input_data"]=$_POST;
			$input_data=$_SESSION["input_data"];

			//---------------- 入力チェック ---------------------------

			$this->check($input_data,$baseData);

			//email重複チェック
			$tmp=$commonDao->get_data_tbl("member","email",$input_data[email]);
			if($tmp){
				$this->addMessage("email","ご入力のメールアドレスは登録されています");
			}

			//-------------- ここまで -----------------------------------
			if (count($this->getMessages()) >0) {
				foreach($this->getMessages() as $err_msg){
					$result_messages[$err_msg->getMessageLevel()]=$err_msg->getMessageBody();
				}

				$this->view->assign("result_messages", $result_messages);
			}
			else {

				//都道府県名
				$input_data[pref_str]=get_pref_name($input_data[pref]);

				//確認画面の表示
				$this->view->assign("input_data", $input_data);

				// HTTPレスポンスヘッダ情報出力
				$this->outHttpResponseHeader();

				$this->setTemplatePath("reserve/regist_confirm.tpl");
				return;



			}
		}
		else if($_POST[submit]){

			//登録直前に再度予約チェック タイムラグ　先に予約登録されている場合もあるので、再チェック
			$chkResult=$this->chkReserve($reserve_datail);
			if(!$chkResult){
				$this->addMessage("error","大変申し訳ございません。予約が埋まってしまいました。<br />予約画面から再度の予約をお願いいたします。");

			}
			else{

				$input_data=$_SESSION["input_data"];

				//基本事項
				foreach($baseData[dbstring] as $key=>$val){
					if($key=="password"){
						$dkey[]=$key;
						$dval[]=to_hash($input_data[$key]);
					}
					else{
						$dkey[]=$key;
						$dval[]=$input_data[$key];
					}
				}

					//----------- 新規登録 ------------

					$dkey[]="insert_date";
					$dval[]=date("Y-m-d H:i:s");

					$input_data[spid]=$input_data[shop_no];//管理画面に合わせる。spidは会員NOの頭に付く番号

					$ret=$memberDao->InsertItemData($dkey, $dval,$input_data,$reserve_datail);

					if($ret){
						//登録者にメールを出す設定であれば出す
						$tmp=$commonDao->get_data_tbl("mst_auto_mail",array("no","mail_flg"),array(1,1));
						if($tmp){

							//body部
							foreach($baseData[dbstring] as $key=>$val){
								if($key!="password"){
									if($key=="shop_no"){
										$bodyMail.="\n\n◆".$val.":".$reserve_datail[shop_name]."\n";
									}
									elseif($key=="pref"){
										$bodyMail.="◆".$val.":".get_pref_name($input_data[$key])."\n";
									}
									elseif($key=="sex"){
										if($val==1){
											$sex_str="男性";
										}
										else{
											$sex_str="女性";
										}
										$bodyMail.="◆".$val.":".$sex_str."\n";
									}
									elseif($key=="mail_flg"){
										if($input_data[$key]==1){
											$mail_flg_str="希望する";
										}
										else{
											$mail_flg_str="希望しない";
										}
										$bodyMail.="◆".$val.":".$mail_flg_str."\n";
									}
									else{
										$bodyMail.="◆".$val.":".$input_data[$key]."\n";
									}
								}
							}

							//署名GET
							$sigtmp=$commonDao->get_data_tbl("mail_sig","","");
							$sig=$sigtmp[0][sig];


							$subject = $tmp[0][subject];
							$mailBody = $tmp[0][header_text].$bodyMail."\n\n".$tmp[0][footer_text]."\n\n".$sig;
							$mailfrom="From:" .mb_encode_mimeheader(MAIL_FROM_NAME) ."<".MAIL_FROM.">";
							send_mail($input_data[email], MAIL_FROM, MAIL_FROM_NAME, $subject, $mailBody);
						}

						//予約者にメールを出す設定であれば出す
												//メール送信
						$this->send_auto_mail($reserve_datail,$input_data[email]);

						$this->view->assign("input_data", $input_data);
						$this->setTemplatePath("reserve/regist_finish.tpl");
						return;

					}
					else{
						$this->addMessage("error","予約登録エラーです。<br />大変申し訳ございませんが、予約画面から再度の予約をお願いいたします。");

						// HTTPレスポンスヘッダ情報出力
						$this->outHttpResponseHeader();

						$this->setTemplatePath("error.tpl");
						return;
					}
			}
		}
		else if(isset($_GET[back])){

			$input_data=$_SESSION["input_data"];

		}
		else{
			//新規登録
			//会員登録確認画面から、予約画面に戻って、再度予約登録処理をした場合には、セッションが残っている。
			if($_SESSION["input_data"]){
				$input_data=$_SESSION["input_data"];
			}
			else{
				//デフォルト
				$input_data[sex]=2;
				$input_data[dm_flg]=1;
				$input_data[mail_flg]=1;

				$input_data[year]="1980";
			}
		}

		//年月日プルダウン
		$yearArr=makeYearList("1945","-10",0);
		$monthArr=makeMonthList(0);
		$dayArr=makeDayList(0);

		$this->view->assign("yearArr", $yearArr);
		$this->view->assign("monthArr", $monthArr);
		$this->view->assign("dayArr", $dayArr);


		$this->view->assign("input_data", $input_data);
		$this->view->assign("prefArr", $prefArr);


		// HTTPレスポンスヘッダ情報出力
		$this->outHttpResponseHeader();

		$this->setTemplatePath("reserve/regist.tpl");

		return;


	}

	/**
	 *  会員登録済みのメンバーの予約処理（マイページから）
	 */
	public function memberAction() {


		$commonDao = new CommonDao();
		$reserveDao=new ReserveDao();
		$memberDao=new MemberDao();
		$login_member=$this->getMemberSession();

		//予約詳細データ
		if(!$_SESSION[reserve_detail]){

			//時間切れエラー/不正エラー

				$this->addMessage("error","タイムアウトエラーです。予約画面から始めてください");

				// HTTPレスポンスヘッダ情報出力
				$this->outHttpResponseHeader();

				$this->setTemplatePath("error.tpl");
				return;

		}
		else{

			$reserve_datail=$this->setReserveDetail();
			$this->view->assign("reserve_datail", $reserve_datail);

		}

		//-------------予約可能かチェック  タイムラグがあるので、予約直前に再度チェック--------------
		$chkResult=$this->chkReserve($reserve_datail);
		if(!$chkResult){
				$this->addMessage("error","大変申し訳ございません。予約が埋まってしまいました。<br />予約画面から再度の予約をお願いいたします。");
		}
		else{

			$dkey[]="member_id";
			$dval[]=$login_member[member_id];
			$dkey[]="number";
			$dval[]=$reserve_datail[number];
			$dkey[]="insert_date";
			$dval[]=date("Y-m-d H:i:s");
			$dkey[]="update_date";
			$dval[]=date("Y-m-d H:i:s");


			//予約詳細登録用に不足データをセット（adminの予約データに合わせる為）
			$reserve_datail[member_id]=$login_member[member_id];
			$reserve_datail[buy_no]=$_POST[buy_no];

			$ret=$reserveDao->InsertItemData($dkey, $dval, $reserve_datail,$reserve_datail[end_time]);
			if($ret){

				//規定回数に達したら、購入コース終了

				//選択コースに対する、予約の回数をカウント（キャンセルを除いて）
				//規定回数の予約が入ったら、そのコースは終了となる。（キャンセルになったら、解除を行う。）
				$memberDao->getCourseCountCheck($_POST[buy_no]);
				$this->addMessage("info","ご希望の時間帯に予約を行いました");

				//予約者にメールを出す設定であれば出す
				//メール送信
				$this->send_auto_mail($reserve_datail,$login_member[email]);

				$input_data[name]=$login_member[name];
				$this->view->assign("input_data", $input_data);

			}
			else{
				$this->addMessage("error","予約登録エラーです。<br />大変申し訳ございませんが、予約画面から再度の予約をお願いいたします。");
				// HTTPレスポンスヘッダ情報出力
				$this->outHttpResponseHeader();

				$this->setTemplatePath("error.tpl");
				return;
			}
		}

		// HTTPレスポンスヘッダ情報出力
		$this->outHttpResponseHeader();

		$this->setTemplatePath("reserve/regist_finish.tpl");

		return;


	}

	/**
	 *  メニュー番号から
	 *
	 *  コースの料金説明とメニューの説明を乗せる
	 *
	 */
	public function menu_detailAction() {


		$commonDao = new CommonDao();

		$menu_no=makeGetRequest($_GET[no]);

		$sql="select *,m.name as menu_name,c.name as course_name from mst_menu as m, mst_course as c where m.course_no=c.course_no and m.menu_no=".$menu_no;
		$tmp=$commonDao->get_sql($sql);

		$this->view->assign("arr", $tmp[0]);


		// HTTPレスポンスヘッダ情報出力
		$this->outHttpResponseHeader();

		$this->setTemplatePath("reserve/menu_detail.tpl");

		return;



	}


	/**
	 *
	 *	選択した店舗のブース数を取得してその数のプルダウンを作成する
	 *
	 */
	public function getNumberAction() {

		$commonDao = new CommonDao();

		$shop_no=$_REQUEST[shop_no];
		$menu_no=$_REQUEST[menu_no];


		//メニューが選択されている場合（menu_no>0)はmenu人数をチェック
		//二人以上の場合は、その人数で決め打ちとする。
		//ブース数プルダウンは店舗が決まっていて、
		//メニューが決まっていない、または、メニューが決まっている場合は人数が一人の時（二人以上の場合は、決め打ちとする）

		if($menu_no>0){

			$tmp=$commonDao->get_data_tbl("mst_menu","menu_no",$menu_no);
			$number=$tmp[0][number];

		}

		if($number>=2){

			$data["html_str"]="<div id='menu_msg'>ご選択のメニューの人数は".$number."人でのお申込みとなっております</div>";

			$boothArr=array($number=>$number);

		}
		else{

			//ブース数
			$tmp=$commonDao->get_data_tbl("shop_attr",array("shop_no","attr_key"),array($shop_no,"booth"));
			$boothArr=makePulldownList(1, $tmp[0][attr_value]);
		}

		$this->view->assign("boothArr", $boothArr);


		$data["html"] = $this->view->fetch("addCategoryPull.tpl");

		echo json_encode($data);
		return;

	}


	//------ セッション情報を変数にセット
	function setReserveDetail(){


		$shopDao = new ShopDAO();
		$commonDao = new CommonDao();

		//予約画面から送られてくるパラメータ詳細
		//$ins[reserve_date]."_".$chkArr[start_time]."_".$ins[end_time]."_".$ins[shop_no]."_".$search[menu_no]."_".$search[number
		//予約日(yyyy/mm/dd)."_".予約開始時間(hh:ii)."_".予約終了時間(hh:ii)."_".店舗番号."_".メニュー番号."_".人数

		$reserve_datailTmp=$_SESSION[reserve_detail];
		$reserve_datail=explode("_",$reserve_datailTmp);

		//店舗名
		$reserve_datail[shop_name]=$shopDao->getShopName($reserve_datail[3]);
		$reserve_datail[shop_no]=$reserve_datail[3];

		//メニュー名
		$reserve_datail[menu_name]=$shopDao->getMenuName($reserve_datail[4]);
		$reserve_datail[menu_no]=$reserve_datail[4];

		//メニューのチケット使用回数
		$tmp=$commonDao->get_data_tbl("mst_menu","menu_no",$reserve_datail[4]);
		$reserve_datail[use_count]=$tmp[0][use_count];

		//人数
		$reserve_datail[number]=$reserve_datail[5];
		//予約日
		$reserve_datail[reserve_date]=$reserve_datail[0];
		$reserve_datail[start_time]=$reserve_datail[1];
		$reserve_datail[end_time]=$reserve_datail[2];

		return $reserve_datail;

	}

	//------ 予約情報から予約可能かチェックするための
	function chkReserve($reserve_datail){

		$commonDao = new CommonDao();
		$reserveDao = new ReserveDAO();

		//ご希望コースの所要時間
		$tmp=$commonDao->get_data_tbl("mst_menu","menu_no",$reserve_datail[menu_no]);
		$rtimes=$tmp[0][times];//所要時間
		$input_data[use_count]=$tmp[0][use_count];//ご希望メニューが何回分のチケットを使うか


		$rsv_date=explode("/",$reserve_datail[reserve_date]);
		$ins[end_time]=$reserve_datail[end_time];

		$ins[shop_no]=$reserve_datail[shop_no];
		$ins[reserve_date]=$reserve_datail[reserve_date];
		$ins[start_time]=$reserve_datail[start_time];

		$tmp=$commonDao->get_data_tbl2("member_reserve_detail",$ins);
		//予約希望時間帯現在の予約数
		$reserve_count_s=$reserveDao->getReserveCount($ins,"start");
		$reserve_count_e=$reserveDao->getReserveCount($ins,"end");

		//店舗のブース数
		$tmp=$commonDao->get_data_tbl("shop_attr",array("shop_no","attr_key"),array($ins[shop_no],"booth"));
		$shop_booth_cnt=$tmp[0][attr_value];

		if($shop_booth_cnt<($reserve_datail[number]+$reserve_count_s) || $shop_booth_cnt<($reserve_datail[number]+$reserve_count_e)){
			return false;
		}


		return true;

	}

	function send_auto_mail($reserve_datail,$email){

		$commonDao = new CommonDao();

		$tmp=$commonDao->get_data_tbl("mst_auto_mail",array("no","mail_flg"),array(2,1));
		if($tmp){

			//署名GET
			$sigtmp=$commonDao->get_data_tbl("mail_sig","","");
			$sig=$sigtmp[0][sig];

			$bodyMail="\n\n◆予約日：".$reserve_datail[reserve_date]."\n";
			$bodyMail.="◆時間：".$reserve_datail[start_time]."～".$reserve_datail[end_time]."\n";
			$bodyMail.="◆人数：".$reserve_datail[number]."人"."\n";
			$bodyMail.="◆店舗：".$reserve_datail[shop_name]."\n\n\n";

			$subject = $tmp[0][subject];
			$mailBody = $tmp[0][header_text].$bodyMail.$tmp[0][footer_text]."\n\n".$sig;
			$mailfrom="From:" .mb_encode_mimeheader(MAIL_FROM_NAME) ."<".MAIL_FROM.">";
			send_mail($email, MAIL_FROM, MAIL_FROM_NAME, $subject, $mailBody);
		}

	}





}
?>
