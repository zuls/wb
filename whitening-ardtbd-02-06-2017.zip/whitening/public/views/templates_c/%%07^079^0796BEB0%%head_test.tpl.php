<?php /* Smarty version 2.6.26, created on 2014-09-16 19:54:22
         compiled from head_test.tpl */ ?>
<html>
<head>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta charset="UTF-8">