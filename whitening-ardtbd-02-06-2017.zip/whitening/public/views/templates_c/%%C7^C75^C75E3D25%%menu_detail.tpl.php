<?php /* Smarty version 2.6.26, created on 2017-03-03 19:14:17
         compiled from reserve/menu_detail.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'number_format', 'reserve/menu_detail.tpl', 33, false),array('modifier', 'nl2br', 'reserve/menu_detail.tpl', 41, false),)), $this); ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "head.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<title>歯のホワイトニング専門店Whitening Bar　予約受付</title>
<meta name="Keywords" content="Whitening Bar, ホワイトニング, 歯のホワイトニング, 予約" />
<meta name="Description" content="歯のホワイトニング専門店Whitening Bar　予約を受け付けいたします。" />

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "head_under.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<script type="text/javascript">
<!--
<?php echo '



'; ?>

-->
</script>

<body>
	<div id="wrap">
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "header_logo.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

		<div class="content">
		<h1>メニュー詳細</h1>
		<form action="" method="post">
			<h2><?php echo $this->_tpl_vars['arr']['course_name']; ?>
　＞　<?php echo $this->_tpl_vars['arr']['menu_name']; ?>
</h2>
			<div class="content-inner">

				<table class="table mt10">
					<tr>
						<th>
							<?php echo $this->_tpl_vars['arr']['course_name']; ?>
料金
						</th>
						<td>
							<?php echo ((is_array($_tmp=$this->_tpl_vars['arr']['fee'])) ? $this->_run_mod_handler('number_format', true, $_tmp) : number_format($_tmp)); ?>
円
						</td>
					</tr>
					<tr>
						<th>
							料金説明
						</th>
						<td>
							<?php echo ((is_array($_tmp=$this->_tpl_vars['arr']['fee_comment'])) ? $this->_run_mod_handler('nl2br', true, $_tmp) : smarty_modifier_nl2br($_tmp)); ?>

						</td>
					</tr>
					<tr>
						<th>
							追記説明
						</th>
						<td>
							<?php echo ((is_array($_tmp=$this->_tpl_vars['arr']['comment'])) ? $this->_run_mod_handler('nl2br', true, $_tmp) : smarty_modifier_nl2br($_tmp)); ?>

						</td>
					</tr>

				</table>
				<div class="tc mt35">
					<button onClick="window.close();" class="btn">閉じる</button>
				</div>
			</div>
		</form>
		</div>
		<div id="push"></div>
	</div><!-- / #wrap -->
	<p id="page-top" style="display: block;">
		<a href="#wrap"><span><i class="fa fa-arrow-up fa-4x"></i></span></a>
	</p>

<script type="text/javascript" charset="UTF-8" src="//navicast.jp/NavicastApi.js?pbeldad"></script>
</body>
</html>