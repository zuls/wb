<?php /* Smarty version 2.6.26, created on 2014-07-15 12:22:03
         compiled from reserve/register.tpl */ ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "head.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<title>歯のホワイトニング専門店Whitening Bar　予約受付</title>
<meta name="Keywords" content="Whitening Bar, ホワイトニング, 歯のホワイトニング, 予約" />
<meta name="Description" content="歯のホワイトニング専門店Whitening Bar　予約を受け付けいたします。" />

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "head_under.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<script type="text/javascript">
<!--
<?php echo '



'; ?>

-->
</script>

<body>
	<div id="wrap">
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "header.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

		<div class="content">
		<h1>会員登録</h1>
		<form action="register_confirm.html">
			<h2>基本情報の登録</h2>
			<div class="content-inner">
				<p>下記項目に入力後、「次へ」ボタンをクリックしてください。</p>
				<table class="table mt10">
					<tr>
						<th>メールアドレス&nbsp;<span class="label">必須</span></th>
						<td><input name="" type="text" class="form-lg"><br><span class="txt-red txt-sm">メールアドレスを入力してください。</span></td>
					</tr>
					<tr>
						<th>パスワード&nbsp;<span class="label">必須</span></th>
						<td><input name="" type="password"><br><span class="txt-sm">半角英数字4～20文字</span></td>
					</tr>
					<tr>
						<th>お名前&nbsp;<span class="label">必須</span></th>
						<td><input name="" type="text"></td>
					</tr>
					<tr>
						<th>フリガナ&nbsp;<span class="label">必須</span></th>
						<td><input name="" type="text"></td>
					</tr>
					<tr>
						<th>電話番号&nbsp;<span class="label">必須</span></th>
						<td><input name="" type="text"><br><span class="txt-sm">-（ハイフン）なしで入力</span></td>
					</tr>
					<tr>
						<th>住所&nbsp;<span class="label">建物名以外必須</span></th>
						<td>
							<span class="address">郵便番号</span><input name="" type="text" class="form-sm"><br>
							<span class="address"></span><span class="txt-sm">-（ハイフン）なしで入力</span><br>
							<span class="address">市区町村・番地</span><input name="" type="text" class="form-lg mt5"><br>
							<span class="address">建物名</span><input name="" type="text" class="form-lg mt5">
						</td>
					</tr>
					<tr>
						<th>性別&nbsp;<span class="label">必須</span></th>
						<td><label><input type="radio" name="sex" value="男性">男性</label><label><input type="radio" name="sex" value="女性">女性</label></td>
					</tr>
					<tr>
						<th>生年月日&nbsp;<span class="label">必須</span></th>
						<td>
							<select name="" class="form-sm">
								<option>選択してください</option>
							</select>年
							<select name="" class="mt5 form-sm">
								<option>選択してください</option>
							</select>月
							<select name="" class="mt5 form-sm">
								<option>選択してください</option>
							</select>日
						</td>
					</tr>
					<tr>
						<th>お店からのお知らせメール&nbsp;<br class="pc"><span class="label">必須</span></th>
						<td><label><input name="mail" type="radio" value="希望する" checked>希望する</label><label><input type="radio" name="mail" value="希望しない">希望しない</label></td>
					</tr>
					<tr>
						<th>備考</th>
						<td><textarea></textarea></td>
					</tr>
				</table>
				<div class="tc mt35"><input type="button" class="btn btn-lg btn-gray" value="戻る">&nbsp;&nbsp;<input name="送信" type="submit" class="btn btn-lg" value="次へ"></div>
			</div>
		</form>
		</div>
		<div id="push"></div>
	</div><!-- / #wrap -->
	<p id="page-top" style="display: block;">
		<a href="#wrap"><span><i class="fa fa-arrow-up fa-4x"></i></span></a>
	</p>

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

</body>
</html>