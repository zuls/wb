<?php /* Smarty version 2.6.26, created on 2014-09-25 18:16:02
         compiled from mail/password.tpl */ ?>
<?php echo $this->_tpl_vars['input_data']['name']; ?>
様

いつもご利用ありがとうございます。


仮パスワードを発行しましたので、こちらからログインして下さい。
ログイン後はメニューのパスワード変更からパスワードの変更をお願いいたします。

仮パスワード
<?php echo $this->_tpl_vars['pass']; ?>



-----------------------------

<?php echo @SITE_TITLE; ?>

URL:<?php echo @ROOT_URL; ?>

メールアドレス:<?php echo @SITE_ADMIN_EMAIL; ?>


----------------------------