<?php /* Smarty version 2.6.26, created on 2016-09-06 20:50:30
         compiled from member/edit.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'html_options', 'member/edit.tpl', 94, false),)), $this); ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "head.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<title>歯のホワイトニング専門店Whitening Bar　予約受付</title>
<meta name="Keywords" content="Whitening Bar, ホワイトニング, 歯のホワイトニング, 予約" />
<meta name="Description" content="歯のホワイトニング専門店Whitening Bar　予約を受け付けいたします。" />
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "head_under.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<script src="https://zipaddr.googlecode.com/svn/trunk/zipaddr7.js" charset="UTF-8"></script>

<body>
	<div id="wrap">

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "header.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

<?php echo '

<!-- Google Tag Manager -->
<noscript><iframe src="//www.googletagmanager.com/ns.html?id=GTM-TNFNQV"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({\'gtm.start\':
new Date().getTime(),event:\'gtm.js\'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!=\'dataLayer\'?\'&l=\'+l:\'\';j.async=true;j.src=
\'//www.googletagmanager.com/gtm.js?id=\'+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,\'script\',\'dataLayer\',\'GTM-TNFNQV\');</script>
<!-- End Google Tag Manager -->

'; ?>



		<div class="content">
		<h1><?php echo $this->_tpl_vars['login_member']['name']; ?>
&nbsp;様&nbsp;登録情報変更</h1>


		<form action="" method="post">
			<h2>基本情報</h2>
			<div class="content-inner">

		<?php if ($this->_tpl_vars['result_messages']): ?>
			<?php $_from = $this->_tpl_vars['result_messages']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['item']):
?>
				<span class="txt-red txt-sm"><?php echo $this->_tpl_vars['item']; ?>
</span><br />
			<?php endforeach; endif; unset($_from); ?>
		<?php endif; ?>


				<p>変更したい項目を再入力後、「変更」ボタンをクリックしてください。</p>
				<table class="table mt10">
					<tr>
						<th>メールアドレス(ログインID）&nbsp;<span class="label">必須</span></th>
						<td>
							 <?php if ($this->_tpl_vars['result_messages']['email']): ?>
								<span class="txt-red txt-sm"><?php echo $this->_tpl_vars['result_messages']['email']; ?>
</span><br />
							<?php endif; ?>

						<input name="email" value="<?php echo $this->_tpl_vars['input_data']['email']; ?>
" type="text" class="form-lg"></td>
					</tr>
					<tr>
						<th>お名前&nbsp;<span class="label">必須</span></th>
						<td>
					 		<?php if ($this->_tpl_vars['result_messages']['name']): ?>
								<span class="txt-red txt-sm"><?php echo $this->_tpl_vars['result_messages']['name']; ?>
</span><br />
							<?php endif; ?>

							<input  name="name" value="<?php echo $this->_tpl_vars['input_data']['name']; ?>
"  type="text"></td>
					</tr>
					<tr>
						<th>ふりがな&nbsp;<span class="label">必須</span></th>
						<td>
					 		<?php if ($this->_tpl_vars['result_messages']['name_kana']): ?>
								<span class="txt-red txt-sm"><?php echo $this->_tpl_vars['result_messages']['name_kana']; ?>
</span><br />
							<?php endif; ?>

							<input name="name_kana" value="<?php echo $this->_tpl_vars['input_data']['name_kana']; ?>
" type="text"></td>
					</tr>
					<tr>
						<th>電話番号&nbsp;<span class="label">必須</span></th>
						<td>
					 		<?php if ($this->_tpl_vars['result_messages']['tel']): ?>
								<span class="txt-red txt-sm"><?php echo $this->_tpl_vars['result_messages']['tel']; ?>
</span><br />
							<?php endif; ?>
						<input name="tel" value="<?php echo $this->_tpl_vars['input_data']['tel']; ?>
"  type="text"></td>
					</tr>
					<tr>
						<th>住所&nbsp;<span class="label">建物名以外必須</span></th>
						<td>
							 <?php if ($this->_tpl_vars['result_messages']['zip']): ?>
								<span class="txt-red txt-sm"><?php echo $this->_tpl_vars['result_messages']['zip']; ?>
</span><br />
							<?php endif; ?>
					          <span class="address">郵便番号</span>
					          <input type="text" id="zip" name="zip" value="<?php echo $this->_tpl_vars['input_data']['zip']; ?>
"  class="form-sm"><br>
					          <span class="address"></span><span class="txt-sm">
					          【住所自動入力】<br />
					          郵番を入力すると、住所の一部が自動入力されます。<br />ハイフン有無、半角・全角、どれでも入力可能です。
					          <br />入力履歴では自動入力が出来ませんのでご注意ください。
					          </span><br>

							<span class="address">都道府県</span><?php echo smarty_function_html_options(array('name' => 'pref','options' => $this->_tpl_vars['prefArr'],'selected' => $this->_tpl_vars['input_data']['pref'],'id' => 'pref'), $this);?>
<br>
							<span class="address">市区町村・番地</span><input  id="city" name="address1" value="<?php echo $this->_tpl_vars['input_data']['address1']; ?>
" type="text" class="form-lg mt5"><br>
							<span class="address">建物名</span><input name="address2" value="<?php echo $this->_tpl_vars['input_data']['address2']; ?>
" type="text" class="form-lg mt5">
						</td>
					</tr>
					<tr>
						<th>性別&nbsp;<span class="label">必須</span></th>
						<td>
							<label><input type="radio"  name="sex" value="1" <?php if ($this->_tpl_vars['input_data']['sex'] == 1): ?>checked<?php endif; ?> />男性</label>
							<label><input type="radio"  name="sex" value="2" <?php if ($this->_tpl_vars['input_data']['sex'] == 2): ?>checked<?php endif; ?> />女性</label>
						</td>
					</tr>
					<tr>
						<th>生年月日&nbsp;<span class="label">必須</span></th>
						<td>
						    <?php echo smarty_function_html_options(array('name' => 'year','options' => $this->_tpl_vars['yearArr'],'selected' => $this->_tpl_vars['input_data']['year'],'class' => "form-sm"), $this);?>

				            年
				            <?php echo smarty_function_html_options(array('name' => 'month','options' => $this->_tpl_vars['monthArr'],'selected' => $this->_tpl_vars['input_data']['month'],'class' => "form-sm"), $this);?>

				            月
				            <?php echo smarty_function_html_options(array('name' => 'day','options' => $this->_tpl_vars['dayArr'],'selected' => $this->_tpl_vars['input_data']['day'],'class' => "form-sm"), $this);?>

				            日
						</td>
					</tr>
<!--
					<tr>
						<th>お店からのお知らせメール&nbsp;<br class="pc"><span class="label">必須</span></th>
						<td>
							<label><input type="radio"  name="mail_flg" value="1" <?php if ($this->_tpl_vars['input_data']['mail_flg'] == 1): ?>checked<?php endif; ?> />希望する</label>
							<label><input type="radio"  name="mail_flg" value="0" <?php if ($this->_tpl_vars['input_data']['mail_flg'] == 0): ?>checked<?php endif; ?> />希望しない</label>
						</td>
					</tr>
 -->
					<tr>
						<th>備考</th>
						<td><textarea name="comment" rows="" cols=""><?php echo $this->_tpl_vars['input_data']['comment']; ?>
</textarea></td>
					</tr>
				</table>
				<div class="tc mt35"><input name="submit" type="submit" class="btn btn-lg" value="変更"></div>
			</div>
		</form>


		</div>
		<div id="push"></div>
	</div><!-- / #wrap -->
	<p id="page-top" style="display: block;">
		<a href="#wrap"><span><i class="fa fa-arrow-up fa-4x"></i></span></a>
	</p>

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<script type="text/javascript" charset="UTF-8" src="//navicast.jp/NavicastApi.js?pbeldad"></script>

<?php echo '

<script type="text/javascript">
  (function () {
    var tagjs = document.createElement("script");
    var s = document.getElementsByTagName("script")[0];
    tagjs.async = true;
    tagjs.src = "//s.yjtag.jp/tag.js#site=07eYmz4";
    s.parentNode.insertBefore(tagjs, s);
  }());
</script>

<noscript>
<iframe src="//b.yjtag.jp/iframe?c=07eYmz4" width="1" height="1" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe>
</noscript>

'; ?>

</body>
</html>