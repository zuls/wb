<?php /* Smarty version 2.6.26, created on 2014-09-16 19:52:52
         compiled from head_under_top_test.tpl */ ?>

<script type="text/javascript">
<!--
<?php echo '

function winopn(no){
	window.open(\'/reserve/menu_detail/?no=\'+no, \'mywindow2\', \'width=980, height=500, menubar=no, toolbar=no, scrollbars=yes\');
}




'; ?>

-->
</script>

</head>