<?php /* Smarty version 2.6.26, created on 2014-06-17 11:48:21
         compiled from getOptionList_js.tpl */ ?>
<script type="text/javascript">
<?php echo '

function getCategoryChange() {
	target1 = $("#form_label");
//	alert("genre.val=" + $("#genre").val());
//	$(".category_list").remove();
	$("#category").empty();
    $("#category").append($("<option>").attr({value: ""}).text("カテゴリーを選択"));
	if($("#genre").val()!=""){

		$.ajaxSetup({scriptCharset:"utf-8"});
		$.ajax({
			type: "POST",
			url: "/category/getCategoryChange/",
			cache : false,
			dataType: "json",
			data : {
				genre: $("#genre").val(),
		//		category:'; ?>
<?php if ($this->_tpl_vars['search']['category']): ?><?php echo $this->_tpl_vars['search']['category']; ?>
<?php else: ?>0<?php endif; ?><?php echo '
		    },
			success: function(data, dataType) {
	//			 alert(data.list);
	            for (key in data.list) {
	//	            alert(key);
		            var sub_category =data.list[key];
		            $("#category").append($("<option>").attr({value: sub_category.category_no}).text(sub_category.category_name));
			    }
	            $(\'#category\').removeAttr(\'disabled\');
	//			target1.before(data.html);
			},
			error: function(xhr, textStatus, errorThrown) {
				alert("Error!" + textStatus+ " " + errorThrown);
			}
		});
	}else{
		$(\'#category\').attr(\'disabled\', \'disabled\');
	}
}

 /**
  * カテゴリ大カテゴリオプション変更
  */
 function onChangeGenreOpt(obj,blank_flg) {
		if(blank_flg == undefined){
			blank_value="---";
		}else{
			blank_value="---";
		}
	if( obj.value==""){
//		var options = new Array();
//		options.push(\'<option value="">\'+blank_value+\'</option>\');
		$("#category").empty();
//		$("#category_sub_no").append(options.join());
	}else{
 		getCategoryOptions(obj.value, "category",blank_value);
	}
 }

 /**
  * サブカテゴリオプションの取得
  */

	function getCategoryOptions(parent_no, target_id,blank_value) {
		alert (parent_no);
		var blank="";
		$.ajaxSetup({scriptCharset:\'utf-8\'});
		$.ajax({
			type: "POST",
			url: "category/getCategoryListJson",
			cache : false,
			dataType: "json",
			data : {
	 			parent_no: parent_no
		    },
			success: function(value, dataType) {
	 			$("#" + target_id).empty();
				//$("#" + target_id).append($("<option>").attr({value: blank}).text(blank_value));
	            for (key in value.list) {
		            var sub_category = value.list[key];
		            $("#" + target_id).append($("<option>").attr({value: sub_category.category_no}).text(sub_category.category_name));
			    }
		//			inputObj.val($("#near_station_dummy").val());
			},
			error: function(xhr, textStatus, errorThrown) {

				alert(\'Error! \' + textStatus + \' \' + errorThrown);
			}
		});
	}

	 /**
	  * 店舗フラグ変更
	  */
	 function onChangeShopFlg() {
		if (document.frm_edit.shop_flg.checked){　//checked チェックが入っていたら
		      document.frm_edit.category_parent_no.disabled = false; //  有効化
		      document.frm_edit.category_sub_no.disabled = false; //  有効化
        }
   		else{
		      document.frm_edit.category_parent_no.disabled = true; //  無効化
		      document.frm_edit.category_sub_no.disabled = true; //  無効化
		      document.frm_edit.category_parent_no.value = ""; //  無効化
		      document.frm_edit.category_sub_no.value = ""; //  無効化
	    }

	 }

 $(document).ready(function(){

 });
'; ?>

</script>