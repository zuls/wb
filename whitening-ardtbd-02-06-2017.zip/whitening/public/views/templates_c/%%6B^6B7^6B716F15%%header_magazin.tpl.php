<?php /* Smarty version 2.6.26, created on 2014-09-24 17:52:35
         compiled from header_magazin.tpl */ ?>

		<header>
			<div class="pc clearfix">
				<div class="logo fl"><a href="http://whiteningbar.jp/"><img src="/images/logo.gif" alt="歯のホワイトニング専門店Whitening Bar"></a></div>
				<div class="nav fr">
					<ul>
						<li><a href="/">ログイン</a></li>
					</ul>
				</div>
			</div>
			<div class="sp clearfix">
				<div class="logo fl"><a href="index.html"><img src="/images/logo_sp.gif" alt="歯のホワイトニング専門店Whitening Bar"></a></div>
				<div class="nav fr">
					<ul>
						<li><a href="/">ログイン</a></li>
					</ul>
				</div>
			</div>
		</header>
