<?php /* Smarty version 2.6.26, created on 2017-03-24 09:13:12
         compiled from mail/reserve.tpl */ ?>
<?php echo @SITE_TITLE; ?>
 運営者様


会員様の御予約がありましたのでお知らせいたします。


【ご予約内容】

◆お名前：<?php echo $this->_tpl_vars['input_data']['name']; ?>
様

◆メールアドレス：<?php echo $this->_tpl_vars['input_data']['email']; ?>


◆予約番号：<?php echo $this->_tpl_vars['reserve_datail']['reserve_no']; ?>


◆予約日：<?php echo $this->_tpl_vars['reserve_datail']['reserve_date']; ?>


◆時間：<?php echo $this->_tpl_vars['reserve_datail']['start_time']; ?>
 ～ <?php echo $this->_tpl_vars['reserve_datail']['end_time']; ?>


◆人数：<?php echo $this->_tpl_vars['reserve_datail']['number']; ?>
人

◆店舗：<?php echo $this->_tpl_vars['reserve_datail']['shop_name']; ?>


◆メニュー：<?php echo $this->_tpl_vars['menu_name']; ?>



