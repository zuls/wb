<?php /* Smarty version 2.6.26, created on 2017-01-09 10:27:23
         compiled from footer.tpl */ ?>

	<footer class="clear" id="footer">
		<div class="pc clearfix">
			<div class="clearfix">
				<div class="fl">
					<ul>
						<li><a href="http://whiteningbar.jp/" target="_blank">WhiteningBAR ホームページ</a></li>
					</ul>
				</div>
				<!-- <div class="fr txt-sm">このサイトはプライバシー保護のためSSL暗号化通信を使用しています。</div> -->
			</div>
		</div>
		<div class="sp clearfix">
			<ul>
				<li><a href="http://whiteningbar.jp/" target="_blank">WhiteningBAR ホームページ</a></li>
			</ul>
			<!-- <p class="tc mt20">このサイトはプライバシー保護のためSSL暗号化通信を使用しています。</p> -->
		</div>
		<p class="clear mt35 tc txt-sm">Copyright (C) 2014-2015 WhiteningBAR. All Rights Reserved.</p>
	</footer>
