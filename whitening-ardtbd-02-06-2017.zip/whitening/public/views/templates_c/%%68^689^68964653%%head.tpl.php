<?php /* Smarty version 2.6.26, created on 2017-01-09 10:27:23
         compiled from head.tpl */ ?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta charset="UTF-8">