<?php /* Smarty version 2.6.26, created on 2017-03-24 18:03:06
         compiled from reserve/regist.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'html_options', 'reserve/regist.tpl', 147, false),)), $this); ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "head.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<title>歯のホワイトニング専門店Whitening Bar　予約受付</title>
<meta name="Keywords" content="Whitening Bar, ホワイトニング, 歯のホワイトニング, 予約" />
<meta name="Description" content="歯のホワイトニング専門店Whitening Bar　予約を受け付けいたします。" />

<script src="https://zipaddr.googlecode.com/svn/trunk/zipaddr7.js" charset="UTF-8"></script>

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "head_under.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>


<?php echo '

<!-- Google Tag Manager -->
<noscript><iframe src="//www.googletagmanager.com/ns.html?id=GTM-TNFNQV"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({\'gtm.start\':
new Date().getTime(),event:\'gtm.js\'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!=\'dataLayer\'?\'&l=\'+l:\'\';j.async=true;j.src=
\'//www.googletagmanager.com/gtm.js?id=\'+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,\'script\',\'dataLayer\',\'GTM-TNFNQV\');</script>
<!-- End Google Tag Manager -->

'; ?>



<body>
	<div id="wrap">
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "header.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

		<div class="content">
		<h1>会員登録</h1>
		<form action="/reserve/regist/" method="post">
			<h2>基本情報の登録</h2>
			<div class="content-inner">

		<?php if ($this->_tpl_vars['result_messages']): ?>
			<div class="box-warning">
			<?php $_from = $this->_tpl_vars['result_messages']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['item']):
?>
				<p class="txt-sm"><i class="fa fa-warning fa-lg"></i>&nbsp;<?php echo $this->_tpl_vars['item']; ?>
</p>
			<?php endforeach; endif; unset($_from); ?>
			</div>
		<?php endif; ?>

				<p>下記項目に入力後、「次へ」ボタンをクリックしてください。</p>
				<table class="table mt10">
					<tr>
						<th>メールアドレス&nbsp;<span class="label">必須</span></th>
						<td>
						 		<?php if ($this->_tpl_vars['result_messages']['email']): ?>
									<span class="txt-red txt-sm"><?php echo $this->_tpl_vars['result_messages']['email']; ?>
</span><br />
								<?php endif; ?>

							<input type="text" name="email" value="<?php echo $this->_tpl_vars['input_data']['email']; ?>
" class="form-lg">
						</td>


					</tr>
					<tr>
						<th>パスワード&nbsp;<span class="label">必須</span></th>
						<td>
					 		<?php if ($this->_tpl_vars['result_messages']['password']): ?>
								<span class="txt-red txt-sm"><?php echo $this->_tpl_vars['result_messages']['password']; ?>
</span><br />
							<?php endif; ?>
				          <input type="password" name="password" value="<?php echo $this->_tpl_vars['input_data']['password']; ?>
"  />
				          <br><span class="txt-sm">半角英数字6文字以上</span>
						</td>
					</tr>
					<tr>
						<th>確認パスワード&nbsp;<span class="label">必須</span></th>
						<td>
					 		<?php if ($this->_tpl_vars['result_messages']['password']): ?>
								<span class="txt-red txt-sm"><?php echo $this->_tpl_vars['result_messages']['password']; ?>
</span><br />
							<?php endif; ?>
				          <input type="password" name="password2" value="<?php echo $this->_tpl_vars['input_data']['password2']; ?>
"  />
						</td>
					</tr>
					<tr>
						<th>お名前&nbsp;
							<?php if ($this->_tpl_vars['memarr']['0']['req_flg'] == 1): ?>
								<span class="label">必須</span>
							<?php endif; ?>
						</th>
						<td>

					 		<?php if ($this->_tpl_vars['result_messages']['name']): ?>
								<span class="txt-red txt-sm"><?php echo $this->_tpl_vars['result_messages']['name']; ?>
</span><br />
							<?php endif; ?>
				          <input type="text" name="name" value="<?php echo $this->_tpl_vars['input_data']['name']; ?>
"  />
				        </td>
					</tr>
					<tr>
						<th>ふりがな&nbsp;
							<?php if ($this->_tpl_vars['memarr']['1']['req_flg'] == 1): ?>
								<span class="label">必須</span>
							<?php endif; ?>
						</th>
				          <td>
					 		<?php if ($this->_tpl_vars['result_messages']['name_kana']): ?>
								<span class="txt-red txt-sm"><?php echo $this->_tpl_vars['result_messages']['name_kana']; ?>
</span><br />
							<?php endif; ?>
				          <input type="text" name="name_kana" value="<?php echo $this->_tpl_vars['input_data']['name_kana']; ?>
"  /></td>
					</tr>
					<tr>
						<th>電話番号&nbsp;
							<?php if ($this->_tpl_vars['memarr']['2']['req_flg'] == 1): ?>
								<span class="label">必須</span>
							<?php endif; ?>
						</th>
				          <td>
					 		<?php if ($this->_tpl_vars['result_messages']['tel']): ?>
								<span class="txt-red txt-sm"><?php echo $this->_tpl_vars['result_messages']['tel']; ?>
</span><br />
							<?php endif; ?>

				          <input type="text" name="tel" value="<?php echo $this->_tpl_vars['input_data']['tel']; ?>
" /></td>
					</tr>

			        <tr>
			          <th>郵便番号&nbsp;
							<?php if ($this->_tpl_vars['memarr']['3']['req_flg'] == 1): ?>
								<span class="label">必須</span>
							<?php endif; ?>

			          </th>
			          <td>
				 		<?php if ($this->_tpl_vars['result_messages']['zip']): ?>
							<span class="txt-red txt-sm"><?php echo $this->_tpl_vars['result_messages']['zip']; ?>
</span><br />
						<?php endif; ?>
			          <input type="text" id="zip" name="zip" value="<?php echo $this->_tpl_vars['input_data']['zip']; ?>
"  />
			          <br />【住所自動入力】<br />
			          郵便番号を入力すると、住所の一部が自動入力されます。<br />ハイフン有無、半角・全角、どれでも入力可能です。
			          <br />入力履歴では自動入力が出来ませんのでご注意ください。

			        </td>
			        </tr>
			        <tr>
			          <th>都道府県&nbsp;
							<?php if ($this->_tpl_vars['memarr']['4']['req_flg'] == 1): ?>
								<span class="label">必須</span>
							<?php endif; ?>

			          </th>
			          <td>
				 		<?php if ($this->_tpl_vars['result_messages']['pref']): ?>
							<span class="txt-red txt-sm"><?php echo $this->_tpl_vars['result_messages']['pref']; ?>
</span><br />
						<?php endif; ?>

						<?php echo smarty_function_html_options(array('name' => 'pref','options' => $this->_tpl_vars['prefArr'],'selected' => $this->_tpl_vars['input_data']['pref'],'id' => 'pref'), $this);?>

					</td>
			        </tr>
			        <tr>
			          <th>市区町村・番地&nbsp;
							<?php if ($this->_tpl_vars['memarr']['5']['req_flg'] == 1): ?>
								<span class="label">必須</span>
							<?php endif; ?>

			          </th>
			          <td>
				 		<?php if ($this->_tpl_vars['result_messages']['address1']): ?>
							<span class="txt-red txt-sm"><?php echo $this->_tpl_vars['result_messages']['address1']; ?>
</span><br />
						<?php endif; ?>

			          <input type="text" id="city" name="address1" value="<?php echo $this->_tpl_vars['input_data']['address1']; ?>
"  /></td>
			        </tr>
			        <tr>
			          <th>建物名
							<?php if ($this->_tpl_vars['memarr']['6']['req_flg'] == 1): ?>
								<span class="label">必須</span>
							<?php endif; ?>

			          </th>
			          <td>
			          <input type="text" name="address2" value="<?php echo $this->_tpl_vars['input_data']['address2']; ?>
"  /></td>
			        </tr>

					<tr>
						<th>性別&nbsp;
							<?php if ($this->_tpl_vars['memarr']['7']['req_flg'] == 1): ?>
								<span class="label">必須</span>
							<?php endif; ?>

						</th>
			          <td>
				 		<?php if ($this->_tpl_vars['result_messages']['sex']): ?>
							<span class="txt-red txt-sm"><?php echo $this->_tpl_vars['result_messages']['sex']; ?>
</span><br />
						<?php endif; ?>
							<input type="radio"  name="sex" value="1" <?php if ($this->_tpl_vars['input_data']['sex'] == 1): ?>checked<?php endif; ?> />男性
							<input type="radio"  name="sex" value="2" <?php if ($this->_tpl_vars['input_data']['sex'] == 2): ?>checked<?php endif; ?> />女性
						</td>
					</tr>
					<tr>
						<th>生年月日&nbsp;
							<?php if ($this->_tpl_vars['memarr']['8']['req_flg'] == 1): ?>
								<span class="label">必須</span>
							<?php endif; ?>
						</th>
				          <td>

				          	<?php echo smarty_function_html_options(array('name' => 'year','options' => $this->_tpl_vars['yearArr'],'selected' => $this->_tpl_vars['input_data']['year'],'class' => "form-sm"), $this);?>

				            年
				            <?php echo smarty_function_html_options(array('name' => 'month','options' => $this->_tpl_vars['monthArr'],'selected' => $this->_tpl_vars['input_data']['month'],'class' => "form-sm"), $this);?>

				            月
				            <?php echo smarty_function_html_options(array('name' => 'day','options' => $this->_tpl_vars['dayArr'],'selected' => $this->_tpl_vars['input_data']['day'],'class' => "form-sm"), $this);?>

				            日
				            </td>
					</tr>
			        <tr>
			          <th>ご紹介者</th>
			          <td>
			          <input type="text" name="intro" value="<?php echo $this->_tpl_vars['input_data']['intro']; ?>
"  />
			          <br />ご紹介者がいる場合には必ず記載してください。
			          </td>
			        </tr>
					<tr>
						<th>備考</th>
						<td><textarea name="comment" rows="" cols=""><?php echo $this->_tpl_vars['input_data']['comment']; ?>
</textarea></td>
					</tr>
				</table>
				<div class="tc mt35">
					<input type="button" class="btn btn-lg btn-gray" value="予約画面に戻る" onClick="location.href='/reserve/list/?back'">&nbsp;&nbsp;
					<input name="confirm" type="submit" class="btn btn-lg" value="確認へ">
					<input type="hidden" name="shop_no" value="<?php echo $this->_tpl_vars['reserve_datail']['shop_no']; ?>
">
				</div>
			</div>
		</form>
		</div>
		<div id="push"></div>
	</div><!-- / #wrap -->
	<p id="page-top" style="display: block;">
		<a href="#wrap"><span><i class="fa fa-arrow-up fa-4x"></i></span></a>
	</p>

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<script type="text/javascript">var smnAdvertiserId = '00001946';</script><script type="text/javascript" src="//cd-ladsp-com.s3.amazonaws.com/script/pixel.js"></script>
<script type="text/javascript">var smnAdvertiserId = '00002059';</script><script type="text/javascript" src="//cd-ladsp-com.s3.amazonaws.com/script/pixel.js"></script>
<!-- Google Code for &#12522;&#12510;&#12540;&#12465;&#12486;&#12451;&#12531;&#12464;&#12522;&#12473;&#12488; -->
<!-- Remarketing tags may not be associated with personally identifiable information or placed on pages related to sensitive categories. For instructions on adding this tag and more information on the above requirements, read the setup guide: google.com/ads/remarketingsetup -->
<?php echo '
<script type="text/javascript">
/* <![CDATA[ */
var google_conversion_id = 988498814;
var google_conversion_label = "pdbTCJKn5AgQ_pat1wM";
var google_custom_params = window.google_tag_params;
var google_remarketing_only = true;
/* ]]> */
</script>
<script type="text/javascript" src="//www.googleadservices.com/pagead/conversion.js">
</script>
<noscript>
<div style="display:inline;">
<img height="1" width="1" style="border-style:none;" alt="" src="//googleads.g.doubleclick.net/pagead/viewthroughconversion/988498814/?value=0&amp;label=pdbTCJKn5AgQ_pat1wM&amp;guid=ON&amp;script=0"/>
</div>
</noscript>
'; ?>

<script type="text/javascript" charset="UTF-8" src="//navicast.jp/NavicastOne.js?u=pbeldad&a=spa&url_id=20150625114614&SA"></script>



<!--CC追記-->

<script type="text/javascript" charset="utf-8" src="//op.searchteria.co.jp/ads/onetag.ad?onetag_id=751"></script>
<script type="text/javascript" charset="utf-8" src="//adn-j.sp.gmossp-sp.jp/js/rt.js?rtid=34e1fe5062425d3f0a549a6bca4b9970" ></script>
<script type="text/javascript" charset="utf-8" src="//op.searchteria.co.jp/ads/onetag.ad?onetag_id=752"></script>

<?php echo '

<script type="text/javascript">
  (function () {
    var tagjs = document.createElement("script");
    var s = document.getElementsByTagName("script")[0];
    tagjs.async = true;
    tagjs.src = "//s.yjtag.jp/tag.js#site=07eYmz4";
    s.parentNode.insertBefore(tagjs, s);
  }());
</script>

<noscript>
<iframe src="//b.yjtag.jp/iframe?c=07eYmz4" width="1" height="1" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe>
</noscript>

'; ?>


</body>
</html>