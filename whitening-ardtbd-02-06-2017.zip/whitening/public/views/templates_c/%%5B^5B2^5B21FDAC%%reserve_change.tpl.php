<?php /* Smarty version 2.6.26, created on 2014-10-10 19:47:30
         compiled from mail/reserve_change.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'replace', 'mail/reserve_change.tpl', 34, false),array('modifier', 'date_format', 'mail/reserve_change.tpl', 36, false),)), $this); ?>
<?php echo @SITE_TITLE; ?>
 運営者様


会員様の御予約に変更がありましたのでお知らせいたします。


【会員様のお名前】

◆お名前：<?php echo $this->_tpl_vars['input_data']['name']; ?>
様

◆メールアドレス：<?php echo $this->_tpl_vars['input_data']['email']; ?>




【変更後のご予約内容】

◆予約番号：<?php echo $this->_tpl_vars['reserve_datail']['reserve_no']; ?>


◆予約日：<?php echo $this->_tpl_vars['reserve_datail']['reserve_date']; ?>


◆時間：<?php echo $this->_tpl_vars['reserve_datail']['start_time']; ?>
 ～ <?php echo $this->_tpl_vars['reserve_datail']['end_time']; ?>


◆人数：<?php echo $this->_tpl_vars['reserve_datail']['number']; ?>
人

◆店舗：<?php echo $this->_tpl_vars['reserve_datail']['shop_name']; ?>


◆メニュー：<?php echo $this->_tpl_vars['menu_name']; ?>



【変更前のご予約内容】

◆予約番号：<?php echo $this->_tpl_vars['oldReserveArr']['reserve_no']; ?>


◆予約日：<?php echo ((is_array($_tmp=$this->_tpl_vars['oldReserveArr']['reserve_date'])) ? $this->_run_mod_handler('replace', true, $_tmp, "-", "/") : smarty_modifier_replace($_tmp, "-", "/")); ?>


◆時間：<?php echo ((is_array($_tmp=$this->_tpl_vars['oldReserveArr']['start_time'])) ? $this->_run_mod_handler('date_format', true, $_tmp, "%H:%M") : smarty_modifier_date_format($_tmp, "%H:%M")); ?>
 ～ <?php echo ((is_array($_tmp=$this->_tpl_vars['oldReserveArr']['end_time'])) ? $this->_run_mod_handler('date_format', true, $_tmp, "%H:%M") : smarty_modifier_date_format($_tmp, "%H:%M")); ?>


◆人数：<?php echo $this->_tpl_vars['oldReserveArr']['number']; ?>
人

◆店舗：<?php echo $this->_tpl_vars['oldshop_name']; ?>


◆メニュー：<?php echo $this->_tpl_vars['oldmenu_name']; ?>

