<?php /* Smarty version 2.6.26, created on 2015-04-22 12:38:02
         compiled from mail/cancel.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'date_format', 'mail/cancel.tpl', 18, false),)), $this); ?>
<?php echo @SITE_TITLE; ?>
 運営者様


会員様より御予約のキャンセルがありましたので
ご確認ください。
※システム上のキャンセル処理は完了しております。


【キャンセル内容】

◆お名前
<?php echo $this->_tpl_vars['input_data']['name']; ?>
様

◆メールアドレス
<?php echo $this->_tpl_vars['input_data']['email']; ?>


◆キャンセルしたご予約日時
<?php echo ((is_array($_tmp=$this->_tpl_vars['input_data']['reserve_date'])) ? $this->_run_mod_handler('date_format', true, $_tmp, "%Y/%m/%d") : smarty_modifier_date_format($_tmp, "%Y/%m/%d")); ?>

<?php echo ((is_array($_tmp=$this->_tpl_vars['input_data']['start_time'])) ? $this->_run_mod_handler('date_format', true, $_tmp, "%H:%M") : smarty_modifier_date_format($_tmp, "%H:%M")); ?>
～

◆キャンセルした店舗
<?php echo $this->_tpl_vars['input_data']['shop_name']; ?>


